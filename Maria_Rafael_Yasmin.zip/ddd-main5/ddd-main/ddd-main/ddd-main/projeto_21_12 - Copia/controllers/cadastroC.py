from flask import Blueprint, render_template, request, jsonify
from repository import PersonRepository, OrdersRepository, ProductRepository

# Instância do repositório
# Inicializa uma instância do repositório de pessoas, responsável por interagir com os dados das pessoas.
person_repository = PersonRepository()

# Criação de um blueprint para o cadastro
# O Blueprint é uma forma de organizar as rotas de forma modular em uma aplicação Flask.
cadastro_controller = Blueprint('cadastro', __name__)

# Rota para exibir a página de cadastro
@cadastro_controller.route('/cadastro')
def cadastro():
    # Obtém todas as pessoas registradas para exibir na página de cadastro (caso seja necessário listar)
    cadastros = person_repository.get_all_persons()
    # Renderiza o template 'cadastro.html', passando os cadastros para exibição na página.
    return render_template('cadastro.html', cadastro=cadastros)

# Rota para adicionar um novo cadastro, acessada através do método POST
@cadastro_controller.route('/cadastro', methods=['POST'])
def add():
    # Captura os dados enviados pelo formulário
    nome = request.form["name"]  # Obtém o valor do campo "name" do formulário
    email = request.form["email"]  # Obtém o valor do campo "email" do formulário
    senha = request.form["password"]  # Obtém o valor do campo "password" do formulário
    telefone = request.form["telephone"]  # Obtém o valor do campo "telephone" do formulário
    data_nascimento = request.form["registration_date"]  # Obtém o valor do campo "registration_date"

    # Adiciona uma nova pessoa ao repositório com os dados fornecidos
    person_repository.add_person(
        name=nome,
        email=email,
        password=senha,
        access_level='user',  # Define o nível de acesso padrão como 'user'
        telefone=telefone,
        register_date=data_nascimento
    )

    # Após o cadastro, renderiza a página de login (ou inicial) para o usuário.
    return render_template('index.html')
