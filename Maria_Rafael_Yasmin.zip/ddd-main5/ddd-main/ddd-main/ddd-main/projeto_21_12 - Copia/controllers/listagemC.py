from flask import Blueprint, render_template  # Importa Blueprint para organizar rotas e render_template para exibir templates
from models.cadastroM import cadastros  # Importa o modelo de cadastros (se necessário)
from repository import PersonRepository  # Importa o repositório para interagir com os dados de usuários
import logging  # Importa logging para registrar informações e erros durante a execução

# Criação do blueprint para gerenciar a listagem de usuários
# O Blueprint permite separar a lógica da listagem em um módulo independente
lista_controller = Blueprint('lista', __name__)

# Rota para exibir a lista de usuários cadastrados
@lista_controller.route('/lista')
def listagem_use():
    # Registra uma mensagem indicando o início da execução da rota
    logging.info("Início da execução da rota /listaU")

    try:
        # Cria uma instância do repositório para acessar os dados de usuários
        lista_repository = PersonRepository()
        
        # Obtém todos os usuários cadastrados
        cadastros = lista_repository.get_all_persons()
        
        # Registra o número de usuários encontrados
        logging.info(f"Usuários carregados com sucesso: {len(cadastros)} encontrados.")

        # Renderiza o template 'listagem.html', passando a lista de cadastros como variável para o template
        return render_template('listagem.html', cadastros=cadastros)
    except Exception as e:
        # Em caso de erro, registra a mensagem de erro
        logging.error(f"Erro ao carregar usuários: {e}")
        
        # Renderiza o template 'erro.html' com uma mensagem de erro e retorna um código HTTP 500 (Erro interno do servidor)
        return render_template('erro.html', mensagem="Erro ao carregar usuários"), 500
