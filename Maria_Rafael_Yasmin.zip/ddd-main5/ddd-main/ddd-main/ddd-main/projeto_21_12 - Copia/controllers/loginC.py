from flask import Flask, render_template, request, redirect, url_for, session, Blueprint, flash
from repository import PersonRepository
from models.homeM import User

# Usuário administrador pré-configurado no código
admin_user = User("admin@gmail.com", "senhaforte", "admin")  # Usuário administrador
user_list = [admin_user]  # Lista de usuários pré-configurados

# Cria um blueprint
# O Blueprint organiza as rotas relacionadas ao login e autenticação em um módulo separado
login_controller = Blueprint('login_controller', __name__)

# Define a rota para a página de login
@login_controller.route('/login', methods=['POST', 'GET'])
def login_page():
    if request.method == "POST":  # Caso seja uma requisição POST
        email = request.form['email']  # Obtém o email do formulário
        password = request.form['password']  # Obtém a senha do formulário

        # 1. Verifica se o usuário está na lista de usuários pré-configurados
        for user in user_list:
            if user.email == email and user.password == password:  # Verifica credenciais
                session['email_logado'] = user.email  # Armazena o email do usuário na sessão
                session['role'] = user.role  # Armazena o papel (admin ou usuário) na sessão

                # Redirecionamento com base no papel do usuário
                if user.role == 'admin':  # Caso o papel seja admin
                    return redirect(url_for('login_controller.admin_page'))
                else:  # Caso seja outro papel
                    return redirect(url_for('login_controller.user_page'))

        # 2. Se não estiver na lista, busca no banco de dados
        person_repository = PersonRepository()  # Instância do repositório
        person = person_repository.get_person_by_email(email)  # Busca o usuário pelo email no banco

        if person and person.password == password:  # Verifica se o usuário foi encontrado e a senha está correta
            session['email_logado'] = person.email  # Armazena o email do usuário na sessão
            session['role'] = person.access_level  # Armazena o nível de acesso na sessão

            # Redirecionamento com base no nível de acesso
            if person.access_level == 'admin':  # Caso o acesso seja admin
                return redirect(url_for('login_controller.admin_page'))
            else:  # Caso seja outro nível de acesso
                return redirect(url_for('login_controller.user_page'))

        # Se nenhum usuário for validado
        flash('Usuário ou senha incorretos.')  # Exibe mensagem de erro
        return redirect(url_for('login_controller.login_page'))

    # Renderiza a página de login se a requisição for GET
    return render_template('login.html')

# Define a rota para a página do administrador
@login_controller.route('/admin')
def admin_page():
    # Verifica se o usuário está logado e se é um administrador
    if 'email_logado' not in session or session.get('role') != 'admin':
        flash("Você precisa estar logado como administrador para acessar essa página.")  # Mensagem de erro
        return redirect(url_for('login_controller.login_page'))  # Redireciona para a página de login
    return render_template('admin.html')  # Renderiza a página do administrador

# Define a rota para listar usuários (somente para administradores)
@login_controller.route('/lista')
def listagem_use():
    # Verifica se o usuário está logado e se é um administrador
    if 'email_logado' not in session or session.get('role') != 'admin':
        flash("Você precisa estar logado como administrador para acessar essa página.")  # Mensagem de erro
        return redirect(url_for('login_controller.login_page'))  # Redireciona para a página de login
    return render_template('listagem.html')  # Renderiza a página de listagem de usuários

# Define a rota para o logout
@login_controller.route('/logout')
def logout():
    session.pop('email_logado', None)  # Remove o email do usuário da sessão
    session.pop('role', None)  # Remove o papel do usuário da sessão
    flash("Você foi deslogado com sucesso.")  # Exibe mensagem de sucesso
    return redirect(url_for('home.home'))  # Redireciona para a página inicial
