from flask import Blueprint, render_template, request, redirect, url_for, session, flash

# Cria um blueprint
# Um blueprint é usado para organizar rotas relacionadas em um módulo separado.
home_controller = Blueprint('home', __name__)

# Define a rota para a página inicial
@home_controller.route('/', methods=['POST', 'GET'])
def home():
    # Obtém o nome do usuário logado (se houver) a partir da sessão.
    usuario_logado = session.get('usuario_logado')
    # Renderiza a página 'index.html', passando o nome do usuário logado como variável para o template.
    return render_template('index.html', usuario=usuario_logado)

# Define a rota para a página "Sobre Nós"
@home_controller.route('/sobre', methods=['POST', 'GET'])
def sobre():
    # Obtém o nome do usuário logado (se houver) a partir da sessão.
    usuario_logado = session.get('usuario_logado')
    # Renderiza a página 'about.html', passando o nome do usuário logado como variável para o template.
    return render_template('about.html', usuario=usuario_logado)

# Define a rota para a página de produtos
@home_controller.route('/produtos', methods=['POST', 'GET'])
def prod():
    # Obtém o nome do usuário logado (se houver) a partir da sessão.
    usuario_logado = session.get('usuario_logado')
    # Renderiza a página 'services.html', passando o nome do usuário logado como variável para o template.
    return render_template('services.html', usuario=usuario_logado)

# Define a rota para a página do carrinho
@home_controller.route('/carrinho', methods=['POST', 'GET'])
def carrinho():
    # Obtém o nome do usuário logado (se houver) a partir da sessão.
    usuario_logado = session.get('usuario_logado')
    # Renderiza a página 'carrinho.html', passando o nome do usuário logado como variável para o template.
    return render_template('carrinho.html', usuario=usuario_logado)

# Função executada antes de cada requisição, para verificar a autenticação do usuário
@home_controller.before_request
def autenticar_usuario():
    # Verifica se a rota solicitada é protegida, ou seja, requer autenticação.
    rota_protegida = request.endpoint in ['home.admin_page', 'home.user_page']
    # Se a rota é protegida e o usuário não está logado, redireciona para a página de login.
    if rota_protegida and 'usuario_logado' not in session:
        return redirect(url_for('login_controller.login_page'))
