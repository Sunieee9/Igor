from flask import Blueprint, jsonify  # Importa o Blueprint para criar rotas e jsonify para retornar JSON
from repository import CategoriaRepository  # Importa o repositório de categorias

# Criação do blueprint para gerenciar as rotas relacionadas às categorias
categoria_controller = Blueprint('categoria', __name__)

# Rota para adicionar a categoria "Joias e Bijuterias"
@categoria_controller.route('/bijuteria')
def add_bijuteria():
    # Definição dos dados da categoria
    name = "Joias e Bijuterias"
    description = "Usados ​​para adicionar sofisticação ao visual"
    
    # Criação de uma instância do repositório de categorias
    category_repository = CategoriaRepository()
    
    # Adiciona a nova categoria usando o método do repositório
    new_category = category_repository.add_category(name=name, description=description)
    
    # Retorna a nova categoria em formato JSON com o código de status 201 (Criado)
    return jsonify(new_category.to_json()), 201

# Rota para adicionar a categoria "Relógios"
@categoria_controller.route('/relogio')
def add_relogio():
    name = "Relógios"
    description = "Combinação de funcionalidade e estilo, variando de modelos clássicos a esportivos"
    category_repository = CategoriaRepository()
    new_category = category_repository.add_category(name=name, description=description)
    return jsonify(new_category.to_json()), 201

# Rota para adicionar a categoria "Óculos de Sol"
@categoria_controller.route('/oculos')
def add_oculos():
    name = "Óculos de Sol"
    description = "Protegem os olhos dos raios UV e são acessórios essenciais para compor um look casual ou elegante"
    category_repository = CategoriaRepository()
    new_category = category_repository.add_category(name=name, description=description)
    return jsonify(new_category.to_json()), 201

# Rota para adicionar a categoria "Bolsas e Mochilas"
@categoria_controller.route('/bolsa')
def add_bolsa():
    name = "Bolsas e Mochilas"
    description = "Acessórios práticos e disponíveis em diversos tamanhos e materiais para diversos benefícios"
    category_repository = CategoriaRepository()
    new_category = category_repository.add_category(name=name, description=description)
    return jsonify(new_category.to_json()), 201

# Rota para adicionar a categoria "Cintos"
@categoria_controller.route('/cinto')
def add_cinto():
    name = "Cintos"
    description = "Usados ​​para ajustar roupas ou como destaque visual"
    category_repository = CategoriaRepository()
    new_category = category_repository.add_category(name=name, description=description)
    return jsonify(new_category.to_json()), 201

# Rota para adicionar a categoria "Lenços e Cachecóis"
@categoria_controller.route('/cachecol')
def add_cachecol():
    name = "Lenços e Cachecóis"
    description = "Acessórios versáteis para qualquer estação, que podem ser usados no pescoço, cabelo ou amarrados à bolsa"
    category_repository = CategoriaRepository()
    new_category = category_repository.add_category(name=name, description=description)
    return jsonify(new_category.to_json()), 201

# Rota para adicionar a categoria "Chapéus e Bonés"
@categoria_controller.route('/chapeu')
def add_chapeu():
    name = "Chapéus e Bonés"
    description = "Complementam o estilo e oferecem proteção contra o sol, variando de modelos clássicos como chapéus de palha a bonés esportivos"
    category_repository = CategoriaRepository()
    new_category = category_repository.add_category(name=name, description=description)
    return jsonify(new_category.to_json()), 201

# Rota para adicionar a categoria "Luvas"
@categoria_controller.route('/luva')
def add_luva():
    name = "Luvas"
    description = "Acessórios funcionais e decorativos, disponíveis em opções de couro, lã ou tecido, ideais para dias frios ou sofisticados"
    category_repository = CategoriaRepository()
    new_category = category_repository.add_category(name=name, description=description)
    return jsonify(new_category.to_json()), 201

# Rota para adicionar a categoria "Sapatos e Calçados"
@categoria_controller.route('/sapato')
def add_sapato():
    name = "Sapatos e Calçados"
    description = "Sapatos elegantes, sofisticados e botas podem ser verdadeiros acessórios para completar um visual"
    category_repository = CategoriaRepository()
    new_category = category_repository.add_category(name=name, description=description)
    return jsonify(new_category.to_json()), 201

# Rota para adicionar a categoria "Acessórios de Cabelo"
@categoria_controller.route('/cabelo')
def add_cabelo():
    name = "Acessórios de Cabelo"
    description = "Incluem tiaras, presilhas, elásticos, bandanas e grampos decorativos que ajudam a realçar o penteado e o estilo pessoal"
    category_repository = CategoriaRepository()
    new_category = category_repository.add_category(name=name, description=description)
    return jsonify(new_category.to_json()), 201
