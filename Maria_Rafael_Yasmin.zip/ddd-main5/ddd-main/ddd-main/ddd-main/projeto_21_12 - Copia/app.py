from flask import Flask, render_template, request
from controllers.loginC import login_controller
from controllers.homeC import home_controller
from controllers.cadastroC import cadastro_controller
from controllers.listagemC import lista_controller
from controllers.categoriaC import categoria_contreller
from controllers.produtosC import produto_controller
from controllers.pedidosC import pedido_controller
from database import init_db
import logging

# Cria uma instância do aplicativo Flask
app = Flask(__name__)

# Define uma chave secreta para proteger a sessão do aplicativo (necessária para sessões em Flask)
app.secret_key = 'MaRiArAfAeLyAsMiN'

# Registra os blueprints para organizar as rotas e controladores
app.register_blueprint(login_controller)  # Registra o blueprint do controlador de login
app.register_blueprint(home_controller)   # Registra o blueprint do controlador da página inicial
app.register_blueprint(cadastro_controller)  # Registra o blueprint do cadastro de usuários
app.register_blueprint(lista_controller)  # Registra o blueprint da lista de usuários
app.register_blueprint(categoria_contreller)
app.register_blueprint(produto_controller)
app.register_blueprint(pedido_controller)


# Configuração básica de logging

logging.basicConfig(
    level=logging.DEBUG,  # Níveis: DEBUG, INFO, WARNING, ERROR, CRITICAL
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("system.log"),  # Salva os logs em um arquivo
        logging.StreamHandler()  # Exibe os logs no terminal
    ]
)

# Teste de log inicial
logging.info("Sistema iniciado!")

@app.before_request
def log_request_info():
    logging.info(f"Requisição recebida: {request.method} {request.url}")
    logging.debug(f"Headers: {request.headers}")
    logging.debug(f"Payload: {request.get_json(silent=True)}")

# Erros

# Trata erros de página não encontrada (status 404) com uma página personalizada
@app.errorhandler(404)
def page_not_found(error):
    # Exibe a página '404.html' quando ocorre um erro 404 (página não encontrada)
    return render_template('404.html'), 404

# Trata erros de erro interno (status 500) com uma página personalizada
@app.errorhandler(500)
def erro_interno(error):
    # Exibe a página '500.html' quando ocorre um erro 500 (erro interno)
    return render_template('500.html'), 500

# Se o arquivo for executado diretamente, inicia o servidor Flask em modo de depuração
if __name__ == '__main__':
    with app.app_context():
        init_db(app)
        app.run(debug=True)
